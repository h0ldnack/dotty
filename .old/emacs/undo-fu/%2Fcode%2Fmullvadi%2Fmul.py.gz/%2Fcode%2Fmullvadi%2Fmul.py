((buffer-size . 7332) (buffer-checksum . "4ca37ad4976fdf5945b79db1b736d8e2dff51400"))
((emacs-buffer-undo-list nil (7254 . 7256) nil (7249 . 7255) (t 25240 1692 829536 39000) nil ("pprint(" . -7239) ((marker . 7256) . -7) 7246 nil (")" . -7257) ((marker . 7256) . -1) ((marker*) . 1) ((marker) . -1) 7258 (t 25240 1687 2536 446000) nil (7255 . 7257) nil (7253 . 7254) nil (7252 . 7254) (t 25240 1677 328537 121000) nil (7250 . 7251) nil (7249 . 7251) (t 25240 1669 831537 644000) nil (7239 . 7240) nil (7244 . 7245) nil (")" . -7244) ((marker . 7256) . -1) ((marker*) . 1) ((marker) . -1) 7245 nil (7239 . 7245) nil (7242 . 7243) nil ("[" . -7242) ((marker . 7256) . -1) 7243 nil ("0][" . -7243) ((marker . 7256) . -3) 7246 nil ("2](" . -7246) ((marker . 7256) . -3) 7249 nil (")" . -7249) ((marker . 7256) . -1) ((marker*) . 1) ((marker) . -1) 7250 (t 25240 1659 381538 374000) nil (7248 . 7250) nil (7246 . 7247) nil (7245 . 7247) nil (7243 . 7244) nil (7242 . 7244) nil (7239 . 7242) nil (7230 . 7239) nil ("    " . -7235) 7244 nil (7231 . 7239) 7236 nil (7224 . 7230) nil (7220 . 7223) nil (7216 . 7221) nil ("c" . -7216) ((marker . 7256) . -1) 7217 nil (7213 . 7217) nil (7209 . 7213) nil ("    " . 7209) ((marker . 7256) . -4) (7213 . 7214) nil ("    " . -7152) ((marker . 7152) . -4) 7164 nil ("
" . -7147) ((marker . 7256) . -1) ((marker . 7147) . -1) 7148 nil ("    " . -7148) ((marker . 7256) . -4) ((marker . 7147) . -4) 7152 nil ("if " . -7152) ((marker . 7256) . -3) ((marker . 7147) . -3) 7155 nil ("subcmd " . -7155) ((marker . 7256) . -7) ((marker . 7147) . -7) 7162 nil ("in " . -7162) ((marker . 7256) . -3) ((marker . 7147) . -3) 7165 nil ("cmds:" . -7165) ((marker . 7256) . -5) ((marker . 7147) . -5) 7170 (t 25240 1635 659540 29000) nil ("[" . -7235) ((marker . 7256) . -1) ("0" . -7236) ((marker . 7256) . -1) ("]" . -7237) ((marker . 7256) . -1) ((marker*) . 1) ((marker) . -1) 7238 nil (7237 . 7238) nil ("[" . -7237) ((marker . 7256) . -1) 7238 nil (7236 . 7238) nil ("0" . -7236) ((marker . 7256) . -1) ("]" . -7237) ((marker . 7256) . -1) ((marker*) . 1) ((marker) . -1) 7238 nil (7236 . 7237) nil (7235 . 7237) nil (7216 . 7222) ("sub" . -7216) ((marker . 7252) . -3) ((marker . 7256) . -3) 7219 nil (7213 . 7219) nil ("-" . -7213) ((marker . 7256) . -1) ("-" . -7214) ((marker . 7256) . -1) 7215 nil (7212 . 7215) nil (7210 . 7211) nil (7208 . 7211) nil (7211 . 7219) ("cli" . -7211) ((marker . 7252) . -3) ((marker . 7256) . -3) 7214 nil (7209 . 7214) nil ("<" . -7209) ((marker . 7256) . -1) 7210 nil (7197 . 7210) nil (7190 . 7198) nil (7189 . 7191) nil (7179 . 7189) nil ("print(\"" . -7179) ((marker . 7252) . -7) ((marker . 7256) . -7) ((marker . 7152) . -7) 7186 nil ("e\")" . -7186) ((marker . 7252) . -1) ((marker . 7256) . -3) ((marker . 7152) . -3) ((marker*) . 1) ((marker) . -3) 7189 (t 25240 1576 534544 156000) nil (7186 . 7187) nil (7185 . 7187) nil (7179 . 7186) nil ("subcmd()" . -7179) ((marker . 7256) . -8) ((marker*) . 1) ((marker) . -8) ((marker*) . 2) ((marker) . -7) 7187 (t 25240 1568 476544 718000) nil (7142 . 7146) nil (7135 . 7143) nil (7131 . 7135) nil (7132 . 7136) ("    " . 7131) ((marker . 7256) . -4) (7135 . 7136) (t 25240 1557 840545 461000) nil ("from icmplib import ping, async_ping
from rich.pretty import pprint
import sys
from bs4 import BeautifulSoup as BS
import json
import subprocess
import os
import re
import secrets
import httpx
import typing as T
import asyncio
import uvloop
import time
import functools
import inspect

asyncio.set_event_loop_policy(uvloop.EventLoopPolicy())


def must_be_root(func):
    \"\"\"
    For commands that require being run as root
    Not used because I don't have a good way of scripting with it
    \"\"\"

    @functools.wraps(func)
    def x():
        uid = os.getuid()
        if uid == 0:
            return func()
        else:
            raise Exception(uid, \"is not root\")

    return x


def check_for_leaks() -> bool:
    \"\"\"Verifies that your connection is reasonably secure\"\"\"
    url = \"https://am.i.mullvad.net/json\"
    with httpx.Client() as client:
        res = client.get(url)
        data = res.json()
        if data[\"blacklisted\"][\"blacklisted\"]:
            return False
        if not data[\"mullvad_exit_ip\"]:
            return False
        return True


def remote_data():
    \"\"\"\"\"\"
    url = \"https://api.mullvad.net/www/relays/all/\"
    with httpx.Client() as client:
        res = client.get(url)
        return res.json()


async def ping_all_hosts(data: list):
    \"\"\"\"\"\"

    async def a(
        ip: str, hostname: str, city_code: str, country_code: str, vpn_proto: str
    ):
        if \":\" in ip:
            family = 6
        else:
            family = 4
        res = await async_ping(
            ip,
            count=18,
            interval=0.8,
            timeout=4,
            id=None,
            source=None,
            family=family,
            privileged=False,
        )
        result = {
            \"hostname\": hostname,
            \"city_code\": city_code,
            \"country_code\": country_code,
            \"vpn_proto\": vpn_proto,
            \"ipv4\": ip,
            \"is_alive\": res.is_alive,
            \"min_rtt\": res.min_rtt,
            \"avg_rtt\": res.avg_rtt,
            \"max_rtt\": res.max_rtt,
            \"packet_loss\": res.packet_loss,
            \"jitter\": res.jitter,
        }
        return result

    ipv4s = list(
        map(
            lambda x: a(
                x[\"ipv4_addr_in\"],
                x[\"hostname\"],
                x[\"city_code\"],
                x[\"country_code\"],
                x[\"type\"],
            ),
            data,
        )
    )
    # My main internet connection does not have ipv6 working, YAY
    # ipv6s = list(filter(None, list(map(lambda x: x[\"ipv6_addr_in\"], data))))
    # ipv6ss = list(map(lambda x: a(x), ipv6s))
    ping4s = await asyncio.gather(*ipv4s)
    # ping6s = await asyncio.gather(*ipv6ss)
    alive = list(filter(lambda x: x[\"is_alive\"], ping4s))
    pings = sorted(alive, key=lambda x: x[\"avg_rtt\"])
    return pings


def get_():
    \"\"\"\"\"\"
    l = remote_data()
    p = asyncio.run(ping_all_hosts(l))
    return p


def filter_vpns(
    protocol: str = \"wireguard\",
    avg_rtt: int = 180,
    max_rtt: int = 210,
    jitter: int = 5,
    packet_loss: float = 0.0,
):
    \"\"\"\"\"\"
    options = get_()
    vpn_proto = list(filter(lambda x: (x[\"vpn_proto\"] == protocol), options))
    packet_loss = list(filter(lambda x: (x[\"packet_loss\"] <= packet_loss), vpn_proto))
    avg_less_then = list(filter(lambda x: (x[\"avg_rtt\"] <= avg_rtt), packet_loss))
    max_less_then = list(filter(lambda x: (x[\"max_rtt\"] <= max_rtt), avg_less_then))
    jitter_less_then = list(filter(lambda x: (x[\"jitter\"] <= jitter), max_less_then))
    return jitter_less_then


def get_current_config() -> str:
    \"\"\"\"\"\"
    cmd = [\"wg show all endpoints\"]
    res = subprocess.run(cmd, shell=True, stdout=subprocess.PIPE)
    conf = res.stdout.decode(\"utf-8\").split(\"\\t\")[0]
    return conf


def is_up() -> bool:
    \"\"\"Checks if wg has any active connections\"\"\"
    config = get_current_config()
    if config == \"\":
        return False
    else:
        return True


def wg_up(config: str) -> bool:
    \"\"\"\"\"\"
    cmd = [\"wg-quick up \" + config]
    try:
        res = subprocess.run(
            cmd, shell=True, stdout=subprocess.DEVNULL, stderr=subprocess.STDOUT
        )
    except Exception as e:
        raise Exception(\"up cmd failed\")
        sys.exit(1)
    if res.returncode == 0:
        print(config, \"is up\")
        return True
    else:
        return False


def wg_down(config: str) -> bool:
    \"\"\"\"\"\"
    cmd = [\"wg-quick down \" + config]
    try:
        res = subprocess.run(
            cmd, shell=True, stdout=subprocess.DEVNULL, stderr=subprocess.STDOUT
        )
    except Exception as e:
        raise Exception(\"Down cmd failed\")
        sys.exit(1)
    if res.returncode == 0:
        print(config, \"is down\")
        return True
    else:
        return False


def get_all_configs() -> T.Union[list, bool]:
    \"\"\"\"\"\"
    cmd = [\"find /etc/wireguard -type f -name '*.conf'\"]
    try:
        res = subprocess.run(cmd, shell=True, stdout=subprocess.PIPE)
    except Exception as e:
        print(e)
        sys.exit(1)
    stdou = list(filter(None, res.stdout.decode(\"utf-8\").split(\"\\n\")))
    if not stdou == \"\":
        basenames = list(map(os.path.basename, stdou))
        configs = list(map(lambda x: x[:-5], basenames))
        return configs
    else:
        return False


def get_random_config(fully_rand: bool = True) -> str:
    \"\"\"\"\"\"
    if fully_rand:
        configs = get_all_configs()
    else:
        configs = filter_vpns()

    if configs:
        rand_conf = secrets.choice(configs)
        if rand_conf != get_current_config():
            print(rand_conf)
            return rand_conf
        else:
            # Should only recur once, so optimization is not a concern
            return get_random_config()


def rotate():
    \"\"\"Switches to a new, random wireguard config\"\"\"
    if is_up():
        wg_down(get_current_config())

    conf = get_random_config()
    u = wg_up(conf)
    if u:
        print(\"Rotated successfully\")
    else:
        print(\"Failed rotating\")


def _local_cmds():
    \"\"\"\"\"\"
    # List of all functions, including imported ones, in local module
    all_functions = list(filter(lambda x: callable(x[1]), list(globals().items())))
    # List of just the functions from this module
    local_functions = list(
        filter(lambda x: (x[1].__module__ == \"__main__\"), all_functions)
    )
    # List of all non-utility functions from this module
    facing_functions = list(
        filter(lambda x: (not re.match(r\"^_.*\", x[0])), local_functions)
    )
    # cli_cmds = list(map(lambda x: x[0], facing_functions))
    return facing_functions


def _help_cmds():
    \"\"\"Extracts docstring from list of 2-tuples, name and func being the values\"\"\"
    cmds = _local_cmds()
    helps = list(map(lambda x: (x[0], x[1], inspect.getdoc(x[1])), cmds))
    return helps


def _exec_on_match(subcmd: str, func_tuple: tuple):
    \"\"\"\"\"\"
    if subcmd == func_tuple[0]:
        func_tuple[1]()

def _help():
    pprint(_help_cmds)          

def main(argv: list):
    cli_cmds = _help_cmds()
    subcmd = argv[1]
    cmds = list(map(lambda x: x[0], cli_cmds))
    if subcmd in cmds:
        subcmd()
    else:
        _help()
    

if __name__ == \"__main__\":
    main(sys.argv)
" . 1) ((marker* . 1) . 7256) ((marker* . 1) . 7256) ((marker* . 1) . 7256) ((marker* . 1) . 7256) ((marker* . 1) . 7256) ((marker . 7130) . -7208) ((marker* . 1) . 7256) ((marker* . 1) . 7256) ((marker* . 1) . 7256) ((marker* . 1) . 7256) ((marker* . 1) . 7256) ((marker* . 1) . 7256) ((marker* . 1) . 7256) ((marker* . 1) . 7256) ((marker* . 1) . 7256) ((marker* . 1) . 7256) ((marker* . 1) . 7256) ((marker* . 1) . 7256) ((marker* . 1) . 7256) ((marker* . 1) . 7256) ((marker* . 1) . 7256) ((marker* . 1) . 7256) ((marker* . 1) . 7256) ((marker* . 1) . 7256) ((marker* . 1) . 7256) ((marker* . 1) . 7256) ((marker* . 1) . 7256) ((marker* . 1) . 7256) ((marker* . 1) . 7256) ((marker* . 1) . 7256) ((marker* . 1) . 7256) ((marker* . 1) . 7256) ((marker* . 1) . 7256) ((marker* . 1) . 7256) ((marker* . 1) . 7256) ((marker* . 1) . 7256) ((marker* . 1) . 7256) ((marker* . 1) . 7256) ((marker* . 1) . 7256) ((marker* . 1) . 7256) ((marker* . 1) . 7256) ((marker* . 1) . 7256) ((marker* . 1) . 7256) ((marker* . 1) . 7256) ((marker* . 1) . 7256) ((marker* . 1) . 7256) ((marker* . 1) . 7256) ((marker* . 1) . 7256) ((marker* . 1) . 7256) ((marker . 1) . -6435) ((marker . 1) . -7089) ((marker . 7252) . -7169) ((marker . 7256) . -7177) ((marker . 6653) . -6543) ((marker*) . 80) ((marker) . -7177) ((marker*) . 81) ((marker) . -7176) (7257 . 14501) 7178 nil (7176 . 7178) nil (7170 . 7176) ("subc" . -7170) ((marker . 7252) . -4) ((marker . 7256) . -4) 7174 nil (7170 . 7174) nil ("_" . -7170) ((marker . 7252) . -1) ((marker . 7256) . -1) 7171 nil ("exec_" . -7171) ((marker . 7252) . -5) ((marker . 7256) . -5) 7176 nil ("on_" . -7176) ((marker . 7252) . -3) ((marker . 7256) . -3) 7179 nil ("match(" . -7179) ((marker . 7252) . -6) ((marker . 7256) . -6) 7185 nil ("subcmd,)" . -7185) ((marker . 7256) . -8) ((marker*) . 1) ((marker) . -8) 7193 nil ("
    for c in cli_cmds:
        _exec_on_match(subcmd, c)
" . -7224) ((marker . 7256) . -58) ((marker) . -58) 7282 nil (7191 . 7192) nil (7185 . 7191) ("sub" . -7185) ((marker . 7252) . -3) ((marker . 7256) . -3) 7188 nil (7185 . 7188) nil (7184 . 7186) nil (7170 . 7184) ("_ex" . -7170) ((marker . 7252) . -3) ((marker . 7256) . -3) 7173 nil (7170 . 7173) nil (7161 . 7170) (t 25240 1490 471550 163000) nil (7009 . 7019) (t 25240 1490 471550 163000) nil (" " . -7009) ((marker . 7256) . -1) (" " . -7010) ((marker . 7256) . -1) (" " . -7011) ((marker . 7256) . -1) (" " . -7012) ((marker . 7256) . -1) (" " . -7013) ((marker . 7256) . -1) (" " . -7014) ((marker . 7256) . -1) (" " . -7015) ((marker . 7256) . -1) (" " . -7016) ((marker . 7256) . -1) (" " . -7017) ((marker . 7256) . -1) (" " . -7018) ((marker . 7256) . -1) 7019 (t 25240 1486 804550 419000) nil (7009 . 7019) 7008 (t 25240 1486 804550 419000) nil (6998 . 7008) ("_help" . -6998) ((marker . 7252) . -5) ((marker . 7256) . -5) 7003 nil (6998 . 7003) nil (6991 . 6999) nil (6986 . 6991) nil (6983 . 6986) nil (")" . -6983) ((marker . 7256) . -1) ((marker*) . 1) ((marker) . -1) 6984 nil (6974 . 6984) nil ("    " . -6974) ((marker . 7256) . -4) 6978 nil ("    " . -6978) ((marker . 7256) . -4) 6982 nil (6973 . 6982) nil (7134 . 7141) nil ("print" . -7134) ((marker . 7252) . -4) ((marker . 7256) . -5) 7139 nil (7134 . 7139) nil (7125 . 7134) nil ("    " . -7120) 7129 nil (7124 . 7129) nil (7115 . 7124) nil (7114 . 7115) nil (";" . -7114) ((marker . 7256) . -1) 7115 nil (7110 . 7115) nil (7080 . 7082) nil (7078 . 7079) nil (7075 . 7079) nil ("L" . -7075) ((marker . 7256) . -1) 7076 nil (7069 . 7076) nil ("v" . -7069) ((marker . 7256) . -1) 7070 nil (7066 . 7070) nil (7066 . 7074) ("cli" . -7066) ((marker . 7252) . -3) ((marker . 7256) . -3) 7069 nil (7068 . 7069) nil (7066 . 7068) nil (7050 . 7068) nil ("print(" . -7050) ((marker . 7256) . -6) 7056 nil ("subcmd)" . -7056) ((marker . 7256) . -7) ((marker*) . 1) ((marker) . -7) 7063 nil (7077 . 7081) nil (7071 . 7077) ("sub" . -7071) ((marker . 7252) . -3) ((marker . 7256) . -3) 7074 nil (7068 . 7074) nil (7064 . 7068) nil (7065 . 7069) ("    " . 7064) ((marker . 7256) . -4) (7063 . 7069) (t 25240 1415 119555 422000) nil ("
" . -6035) ((marker . 7130) . -1) ((marker . 7256) . -1) ("
" . -6036) ((marker . 7130) . -1) ((marker . 7256) . -1) 6037 nil ("
def _get_help():
    \"\"\"\"\"\"
    print(\"HELPP MEEEE\")" . 6037) ((marker . 7130) . -53) ((marker) . -53) (t 25240 1402 674556 291000) nil (" " . 4320) nil (" " . 4736) (t 25240 1380 990557 804000) nil ("
" . -3774) ((marker . 7252) . -1) ((marker . 7256) . -1) 3775 nil ("    " . -3775) ((marker . 7252) . -4) ((marker . 7256) . -4) 3779 nil ("print()" . -3779) ((marker . 7252) . -4) ((marker . 7256) . -7) ((marker*) . 1) ((marker) . -7) ((marker*) . 2) ((marker) . -6) 3786 nil (3779 . 3786) nil (3774 . 3779) nil ("
" . -3774) ((marker . 7256) . -1) 3775 nil ("    " . -3775) ((marker . 7256) . -4) 3779 nil (")" . 3779) nil ("(conf" . 3779) ((marker*) . 5) ((marker) . -1) nil ("print" . 3779) (t 25240 1335 796560 959000) nil (7131 . 7135) nil (7129 . 7131) nil (7123 . 7130) nil (7118 . 7123) nil (7116 . 7117) nil ("0" . 7116) (t 25240 1292 429563 986000) nil ("_" . -7085) ((marker . 7256) . -1) 7086 nil ("local_" . -7086) ((marker . 7256) . -6) 7092 nil ("cmds()" . -7092) ((marker . 7256) . -6) ((marker*) . 1) ((marker) . -6) ((marker*) . 2) ((marker) . -5) 7098 nil ("
" . -7098) ((marker . 7256) . -1) 7099 nil ("    " . -7099) ((marker . 7256) . -4) 7103 nil ("
" . -7069) ((marker . 7256) . -1) 7070 (t 25240 1279 630564 879000) nil (6789 . 6805) nil ("e" . -6789) ((marker . 7256) . -1) 6790 nil (6788 . 6790) nil ("t" . -6788) ((marker . 7252) . -1) ((marker . 7256) . -1) ("i" . -6789) ((marker . 7252) . -1) ((marker . 7256) . -1) ("o" . -6790) ((marker . 7252) . -1) ((marker . 7256) . -1) 6791 nil (6790 . 6791) nil (6786 . 6790) nil (6765 . 6786) nil ("t" . -6765) ((marker . 7252) . -1) ((marker . 7256) . -1) ("i" . -6766) ((marker . 7252) . -1) ((marker . 7256) . -1) 6767 nil (6757 . 6767) nil ("i" . -6757) ((marker . 7256) . -1) 6758 nil (6757 . 6758) nil (6753 . 6757) nil ("o" . -6753) ((marker . 7256) . -1) ("r" . -6754) ((marker . 7256) . -1) 6755 nil (6742 . 6755) nil ("h" . -6742) ((marker . 7252) . -1) ((marker . 7256) . -1) ("e" . -6743) ((marker . 7252) . -1) ((marker . 7256) . -1) 6744 nil (6735 . 6744) nil ("c" . -6735) ((marker . 7252) . -1) ((marker . 7256) . -1) 6736 nil (6733 . 6736) nil (6731 . 6736) nil (6730 . 6731) nil (6725 . 6730) nil ("
    def d(x: tuple):
        if x[2] is None:
            return (x[0], x[1], \"n/a\")
        elif isinstance(x[2], str):
            return (x[0], x[1], x[2].strip())
" . 6725) ((marker . 7130) . -168) ((marker) . -168) nil ("
" . -6992) ((marker . 7256) . -1) ("    " . -6993) ((marker . 7256) . -4) 6997 nil (")" . 6997) (")" . 6997) nil (", helps" . 6997) nil ("(d" . 6997) ((marker*) . 2) ((marker) . -1) nil ("(map" . 6997) ((marker*) . 4) ((marker) . -1) nil (" = list" . 6997) nil ("helpss" . 6997) nil (7030 . 7037) nil ("pprint(" . -7030) ((marker . 7256) . -7) 7037 nil (")" . -7042) ((marker . 7256) . -1) ((marker*) . 1) ((marker) . -1) 7043 (t 25240 1232 712568 154000) nil ("s" . -7042) ((marker . 7252) . -1) ((marker . 7256) . -1) 7043 (t 25240 1230 323568 321000) nil (7001 . 7002) (t 25240 1227 644568 508000) nil (7041 . 7042) (t 25240 1210 412569 710000) nil ("    " . -7188) ((marker . 7256) . -4) 7192 nil ("\"" . -7192) ((marker . 7256) . -1) ("\"" . -7193) ((marker . 7256) . -1) ("\"" . -7194) ((marker . 7256) . -1) ("\"" . -7195) ((marker . 7256) . -1) ("\"" . -7196) ((marker . 7256) . -1) ("\"" . -7197) ((marker . 7256) . -1) 7198 (t 25240 1194 883570 794000) nil (nil ws-butler-chg delete 7198 . 7199) (7181 . 7198) nil ("list):
    \"\"\"\"\"\"" . -7181) ((marker . 7256) . -17) 7198 (t 25240 1194 883570 794000) nil ("s" . -7041) ((marker . 7256) . -1) 7042 nil ("s" . -7002) ((marker . 7256) . -1) 7003 (t 25240 1189 283571 185000) nil ("from icmplib import ping, async_ping
from rich.pretty import pprint
import sys
from bs4 import BeautifulSoup as BS
import json
import subprocess
import os
import re
import secrets
import httpx
import typing as T
import asyncio
import uvloop
import time
import functools
import inspect

asyncio.set_event_loop_policy(uvloop.EventLoopPolicy())


def must_be_root(func):
    \"\"\"
    For commands that require being run as root
    Not used because I don't have a good way of scripting with it
    \"\"\"

    @functools.wraps(func)
    def x():
        uid = os.getuid()
        if uid == 0:
            return func()
        else:
            raise Exception(uid, \"is not root\")

    return x


def check_for_leaks() -> bool:
    \"\"\"Verifies that your connection is reasonably secure\"\"\"
    url = \"https://am.i.mullvad.net/json\"
    with httpx.Client() as client:
        res = client.get(url)
        data = res.json()
        if data[\"blacklisted\"][\"blacklisted\"]:
            return False
        if not data[\"mullvad_exit_ip\"]:
            return False
        return True


def remote_data():
    \"\"\"\"\"\"
    url = \"https://api.mullvad.net/www/relays/all/\"
    with httpx.Client() as client:
        res = client.get(url)
        return res.json()


async def ping_all_hosts(data: list):
    \"\"\"\"\"\"

    async def a(
        ip: str, hostname: str, city_code: str, country_code: str, vpn_proto: str
    ):
        if \":\" in ip:
            family = 6
        else:
            family = 4
        res = await async_ping(
            ip,
            count=18,
            interval=0.8,
            timeout=4,
            id=None,
            source=None,
            family=family,
            privileged=False,
        )
        result = {
            \"hostname\": hostname,
            \"city_code\": city_code,
            \"country_code\": country_code,
            \"vpn_proto\": vpn_proto,
            \"ipv4\": ip,
            \"is_alive\": res.is_alive,
            \"min_rtt\": res.min_rtt,
            \"avg_rtt\": res.avg_rtt,
            \"max_rtt\": res.max_rtt,
            \"packet_loss\": res.packet_loss,
            \"jitter\": res.jitter,
        }
        return result

    ipv4s = list(
        map(
            lambda x: a(
                x[\"ipv4_addr_in\"],
                x[\"hostname\"],
                x[\"city_code\"],
                x[\"country_code\"],
                x[\"type\"],
            ),
            data,
        )
    )
    # My main internet connection does not have ipv6 working, YAY
    # ipv6s = list(filter(None, list(map(lambda x: x[\"ipv6_addr_in\"], data))))
    # ipv6ss = list(map(lambda x: a(x), ipv6s))
    ping4s = await asyncio.gather(*ipv4s)
    # ping6s = await asyncio.gather(*ipv6ss)
    alive = list(filter(lambda x: x[\"is_alive\"], ping4s))
    pings = sorted(alive, key=lambda x: x[\"avg_rtt\"])
    return pings


def get_():
    \"\"\"\"\"\"
    l = remote_data()
    p = asyncio.run(ping_all_hosts(l))
    return p


def filter_vpns(
    protocol: str = \"wireguard\",
    avg_rtt: int = 180,
    max_rtt: int = 210,
    jitter: int = 5,
    packet_loss: float = 0.0,
):
    \"\"\"\"\"\"
    options = get_()
    vpn_proto = list(filter(lambda x: (x[\"vpn_proto\"] == protocol), options))
    packet_loss = list(filter(lambda x: (x[\"packet_loss\"] <= packet_loss), vpn_proto))
    avg_less_then = list(filter(lambda x: (x[\"avg_rtt\"] <= avg_rtt), packet_loss))
    max_less_then = list(filter(lambda x: (x[\"max_rtt\"] <= max_rtt), avg_less_then))
    jitter_less_then = list(filter(lambda x: (x[\"jitter\"] <= jitter), max_less_then))
    return jitter_less_then


def get_current_config() -> str:
    \"\"\"\"\"\"
    cmd = [\"wg show all endpoints\"]
    res = subprocess.run(cmd, shell=True, stdout=subprocess.PIPE)
    conf = res.stdout.decode(\"utf-8\").split(\"\\t\")[0]
    print(conf)
    return conf


def is_up() -> bool:
    \"\"\"Checks if wg has any active connections\"\"\"
    config = get_current_config()
    if config == \"\":
        return False
    else:
        return True


def wg_up(config: str) -> bool:
    \"\"\"\"\"\"
    cmd = [\"wg-quick up \" + config]
    try:
        res = subprocess.run(
            cmd, shell=True, stdout=subprocess.DEVNULL, stderr=subprocess.STDOUT
        )
    except Exception as e:
        raise Exception(\"up cmd failed\")
        sys.exit(1)
    if res.returncode == 0:
        print(config, \" is up\")
        return True
    else:
        return False


def wg_down(config: str) -> bool:
    \"\"\"\"\"\"
    cmd = [\"wg-quick down \" + config]
    try:
        res = subprocess.run(
            cmd, shell=True, stdout=subprocess.DEVNULL, stderr=subprocess.STDOUT
        )
    except Exception as e:
        raise Exception(\"Down cmd failed\")
        sys.exit(1)
    if res.returncode == 0:
        print(config, \" is down\")
        return True
    else:
        return False


def get_all_configs() -> T.Union[list, bool]:
    \"\"\"\"\"\"
    cmd = [\"find /etc/wireguard -type f -name '*.conf'\"]
    try:
        res = subprocess.run(cmd, shell=True, stdout=subprocess.PIPE)
    except Exception as e:
        print(e)
        sys.exit(1)
    stdou = list(filter(None, res.stdout.decode(\"utf-8\").split(\"\\n\")))
    if not stdou == \"\":
        basenames = list(map(os.path.basename, stdou))
        configs = list(map(lambda x: x[:-5], basenames))
        return configs
    else:
        return False


def get_random_config(fully_rand: bool = True) -> str:
    \"\"\"\"\"\"
    if fully_rand:
        configs = get_all_configs()
    else:
        configs = filter_vpns()

    if configs:
        rand_conf = secrets.choice(configs)
        if rand_conf != get_current_config():
            print(rand_conf)
            return rand_conf
        else:
            # Should only recur once, so optimization is not a concern
            return get_random_config()


def rotate():
    \"\"\"Switches to a new, random wireguard config\"\"\"
    if is_up():
        wg_down(get_current_config())

    conf = get_random_config()
    u = wg_up(conf)
    if u:
        print(\"Rotated successfully\")
    else:
        print(\"Failed rotating\")


def _get_help():
    \"\"\"\"\"\"
    print(\"HELPP MEEEE\")


def _local_cmds():
    \"\"\"\"\"\"
    # List of all functions, including imported ones, in local module
    all_functions = list(filter(lambda x: callable(x[1]), list(globals().items())))
    # List of just the functions from this module
    local_functions = list(
        filter(lambda x: (x[1].__module__ == \"__main__\"), all_functions)
    )
    # List of all non-utility functions from this module
    facing_functions = list(
        filter(lambda x: (not re.match(r\"^_.*\", x[0])), local_functions)
    )
    # cli_cmds = list(map(lambda x: x[0], facing_functions))
    return facing_functions


def _help_cmds():

    def d(x: tuple):
        if x[2] is None:
            return (x[0], x[1], \"n/a\")
        elif isinstance(x[2], str):
            return (x[0], x[1], x[2].strip())

    cmds = _local_cmds()
    helps = list(map(lambda x: (x[0], x[1], inspect.getdoc(x[1])), cmds))
    helpss = list(map(d, helps))
    pprint(helpss)


def _exec_on_match(subcmd: str, func_tuple: tuple):
    \"\"\"\"\"\"
    if subcmd == func_tuple[0]:
        func_tuple[1]()


def main(argv: list):
    \"\"\"\"\"\"
    cli_cmds = _local_cmds()
    _help_cmds()
    subcmd = argv[0]
    for c in cli_cmds:
        _exec_on_match(subcmd, c)


if __name__ == \"__main__\":
    main(sys.argv)
" . 1) ((marker* . 1) . 7373) ((marker* . 1) . 7373) ((marker* . 1) . 7373) ((marker* . 1) . 7373) ((marker* . 1) . 7373) ((marker . 7130) . -6724) ((marker* . 1) . 7373) ((marker* . 1) . 7373) ((marker . 6653) . -6294) ((marker . 7256) . -6724) ((marker* . 1) . 7373) ((marker* . 1) . 7373) ((marker* . 1) . 7373) ((marker* . 1) . 7373) ((marker* . 1) . 7373) ((marker* . 1) . 7373) ((marker* . 1) . 7373) ((marker* . 1) . 7373) ((marker* . 1) . 7373) ((marker* . 1) . 7373) ((marker* . 1) . 7373) ((marker* . 1) . 7373) ((marker* . 1) . 7373) ((marker* . 1) . 7373) ((marker* . 1) . 7373) ((marker* . 1) . 7373) ((marker* . 1) . 7373) ((marker* . 1) . 7373) ((marker* . 1) . 7373) ((marker* . 1) . 7373) ((marker* . 1) . 7373) ((marker* . 1) . 7373) ((marker* . 1) . 7373) ((marker* . 1) . 7373) ((marker* . 1) . 7373) ((marker* . 1) . 7373) ((marker* . 1) . 7373) ((marker* . 1) . 7373) ((marker* . 1) . 7373) ((marker* . 1) . 7373) ((marker* . 1) . 7373) ((marker* . 1) . 7373) ((marker* . 1) . 7373) ((marker* . 1) . 7373) ((marker* . 1) . 7373) ((marker* . 1) . 7373) ((marker* . 1) . 7373) ((marker* . 1) . 7373) ((marker* . 1) . 7373) ((marker* . 1) . 7373) ((marker* . 1) . 7373) ((marker) . -3545) ((marker) . -3546) ((marker) . -3459) ((marker) . -3460) ((marker) . -3374) ((marker) . -3375) ((marker) . -3291) ((marker) . -3292) ((marker) . -3204) ((marker) . -3205) ((marker) . -3126) ((marker) . -3127) ((marker) . -3105) ((marker) . -3106) ((marker) . -3094) ((marker) . -3095) ((marker) . -3061) ((marker) . -3062) ((marker) . -3040) ((marker) . -3041) ((marker) . -3016) ((marker) . -3017) ((marker) . -2992) ((marker) . -2993) ((marker) . -2959) ((marker) . -2960) ((marker) . -2927) ((marker) . -2928) ((marker) . -2888) ((marker) . -2889) ((marker) . -2866) ((marker) . -2867) ((marker) . -2855) ((marker) . -2856) ((marker) . -2824) ((marker) . -2825) ((marker) . -2770) ((marker) . -2771) ((marker) . -2712) ((marker) . -2713) ((marker) . -2667) ((marker) . -2668) ((marker) . -2625) ((marker) . -2626) ((marker) . -424) ((marker) . -425) ((marker) . -376) ((marker) . -377) ((marker) . -368) ((marker) . -369) ((marker) . -586) ((marker) . -587) ((marker) . -590) ((marker) . -591) ((marker) . -594) ((marker) . -595) ((marker) . -565) ((marker) . -566) ((marker) . -569) ((marker) . -570) ((marker) . -539) ((marker) . -540) ((marker) . -543) ((marker) . -544) ((marker) . -526) ((marker) . -527) ((marker) . -499) ((marker) . -500) ((marker) . -490) ((marker) . -491) ((marker) . -721) ((marker) . -722) ((marker) . -675) ((marker) . -676) ((marker) . -626) ((marker) . -627) ((marker) . -630) ((marker) . -631) ((marker) . -634) ((marker) . -635) ((marker) . -612) ((marker) . -613) ((marker) . -616) ((marker) . -617) ((marker) . -1052) ((marker) . -1053) ((marker) . -1056) ((marker) . -1057) ((marker) . -1027) ((marker) . -1028) ((marker) . -1031) ((marker) . -1032) ((marker) . -1035) ((marker) . -1036) ((marker) . -987) ((marker) . -988) ((marker) . -991) ((marker) . -992) ((marker) . -962) ((marker) . -963) ((marker) . -966) ((marker) . -967) ((marker) . -970) ((marker) . -971) ((marker) . -915) ((marker) . -916) ((marker) . -919) ((marker) . -920) ((marker) . -889) ((marker) . -890) ((marker) . -893) ((marker) . -894) ((marker) . -859) ((marker) . -860) ((marker) . -863) ((marker) . -864) ((marker) . -824) ((marker) . -825) ((marker) . -782) ((marker) . -783) ((marker) . -1487) ((marker) . -1488) ((marker) . -1491) ((marker) . -1492) ((marker) . -1464) ((marker) . -1465) ((marker) . -1468) ((marker) . -1469) ((marker) . -1472) ((marker) . -1473) ((marker) . -1450) ((marker) . -1451) ((marker) . -1454) ((marker) . -1455) ((marker) . -1427) ((marker) . -1428) ((marker) . -1431) ((marker) . -1432) ((marker) . -1435) ((marker) . -1436) ((marker) . -1405) ((marker) . -1406) ((marker) . -1409) ((marker) . -1410) ((marker) . -1398) ((marker) . -1399) ((marker) . -1316) ((marker) . -1317) ((marker) . -1320) ((marker) . -1321) ((marker) . -1299) ((marker) . -1300) ((marker) . -1287) ((marker) . -1288) ((marker) . -1221) ((marker) . -1222) ((marker) . -1225) ((marker) . -1226) ((marker) . -1191) ((marker) . -1192) ((marker) . -1195) ((marker) . -1196) ((marker) . -1156) ((marker) . -1157) ((marker) . -1104) ((marker) . -1105) ((marker) . -1093) ((marker) . -1094) ((marker) . -2625) ((marker) . -2626) ((marker) . -2577) ((marker) . -2578) ((marker) . -2498) ((marker) . -2499) ((marker) . -2432) ((marker) . -2433) ((marker) . -2426) ((marker) . -2427) ((marker) . -2416) ((marker) . -2417) ((marker) . -2420) ((marker) . -2421) ((marker) . -2398) ((marker) . -2399) ((marker) . -2402) ((marker) . -2403) ((marker) . -2406) ((marker) . -2407) ((marker) . -2383) ((marker) . -2384) ((marker) . -2387) ((marker) . -2388) ((marker) . -2391) ((marker) . -2392) ((marker) . -2356) ((marker) . -2357) ((marker) . -2360) ((marker) . -2361) ((marker) . -2364) ((marker) . -2365) ((marker) . -2368) ((marker) . -2369) ((marker) . -2321) ((marker) . -2322) ((marker) . -2325) ((marker) . -2326) ((marker) . -2329) ((marker) . -2330) ((marker) . -2333) ((marker) . -2334) ((marker) . -2289) ((marker) . -2290) ((marker) . -2293) ((marker) . -2294) ((marker) . -2297) ((marker) . -2298) ((marker) . -2301) ((marker) . -2302) ((marker) . -2258) ((marker) . -2259) ((marker) . -2262) ((marker) . -2263) ((marker) . -2266) ((marker) . -2267) ((marker) . -2270) ((marker) . -2271) ((marker) . -2223) ((marker) . -2224) ((marker) . -2227) ((marker) . -2228) ((marker) . -2231) ((marker) . -2232) ((marker) . -2235) ((marker) . -2236) ((marker) . -2198) ((marker) . -2199) ((marker) . -2202) ((marker) . -2203) ((marker) . -2206) ((marker) . -2207) ((marker) . -2185) ((marker) . -2186) ((marker) . -2189) ((marker) . -2190) ((marker) . -2167) ((marker) . -2168) ((marker) . -2144) ((marker) . -2145) ((marker) . -2148) ((marker) . -2149) ((marker) . -2134) ((marker) . -2135) ((marker) . -2138) ((marker) . -2139) ((marker) . -2100) ((marker) . -2101) ((marker) . -2104) ((marker) . -2105) ((marker) . -2108) ((marker) . -2109) ((marker) . -2056) ((marker) . -2057) ((marker) . -2060) ((marker) . -2061) ((marker) . -2064) ((marker) . -2065) ((marker) . -2020) ((marker) . -2021) ((marker) . -2024) ((marker) . -2025) ((marker) . -2028) ((marker) . -2029) ((marker) . -1984) ((marker) . -1985) ((marker) . -1988) ((marker) . -1989) ((marker) . -1992) ((marker) . -1993) ((marker) . -1948) ((marker) . -1949) ((marker) . -1952) ((marker) . -1953) ((marker) . -1956) ((marker) . -1957) ((marker) . -1910) ((marker) . -1911) ((marker) . -1914) ((marker) . -1915) ((marker) . -1918) ((marker) . -1919) ((marker) . -1886) ((marker) . -1887) ((marker) . -1890) ((marker) . -1891) ((marker) . -1894) ((marker) . -1895) ((marker) . -1850) ((marker) . -1851) ((marker) . -1854) ((marker) . -1855) ((marker) . -1858) ((marker) . -1859) ((marker) . -1808) ((marker) . -1809) ((marker) . -1812) ((marker) . -1813) ((marker) . -1816) ((marker) . -1817) ((marker) . -1772) ((marker) . -1773) ((marker) . -1776) ((marker) . -1777) ((marker) . -1780) ((marker) . -1781) ((marker) . -1738) ((marker) . -1739) ((marker) . -1742) ((marker) . -1743) ((marker) . -1746) ((marker) . -1747) ((marker) . -1719) ((marker) . -1720) ((marker) . -1723) ((marker) . -1724) ((marker) . -1709) ((marker) . -1710) ((marker) . -1713) ((marker) . -1714) ((marker) . -1679) ((marker) . -1680) ((marker) . -1683) ((marker) . -1684) ((marker) . -1687) ((marker) . -1688) ((marker) . -1652) ((marker) . -1653) ((marker) . -1656) ((marker) . -1657) ((marker) . -1660) ((marker) . -1661) ((marker) . -1627) ((marker) . -1628) ((marker) . -1631) ((marker) . -1632) ((marker) . -1635) ((marker) . -1636) ((marker) . -1606) ((marker) . -1607) ((marker) . -1610) ((marker) . -1611) ((marker) . -1614) ((marker) . -1615) ((marker) . -1583) ((marker) . -1584) ((marker) . -1587) ((marker) . -1588) ((marker) . -1591) ((marker) . -1592) ((marker) . -1557) ((marker) . -1558) ((marker) . -1561) ((marker) . -1562) ((marker) . -1565) ((marker) . -1566) ((marker) . -1535) ((marker) . -1536) ((marker) . -1539) ((marker) . -1540) ((marker) . -1543) ((marker) . -1544) ((marker) . -1519) ((marker) . -1520) ((marker) . -1523) ((marker) . -1524) ((marker) . -1527) ((marker) . -1528) ((marker . 1) . -3607) ((marker . 1) . -3575) ((marker) . -3619) ((marker) . -3620) ((marker) . -3608) ((marker) . -3609) ((marker) . -3774) ((marker) . -3775) ((marker) . -3721) ((marker) . -3722) ((marker) . -3655) ((marker) . -3656) ((marker) . -3790) ((marker) . -3791) ((marker) . -3955) ((marker) . -3956) ((marker) . -3934) ((marker) . -3935) ((marker) . -3938) ((marker) . -3939) ((marker) . -3913) ((marker) . -3914) ((marker) . -3879) ((marker) . -3880) ((marker) . -3829) ((marker) . -3830) ((marker) . -4030) ((marker) . -4031) ((marker) . -4019) ((marker) . -4020) ((marker) . -3965) ((marker) . -3966) ((marker) . -3969) ((marker) . -3970) ((marker) . -4264) ((marker) . -4265) ((marker) . -4268) ((marker) . -4269) ((marker) . -4223) ((marker) . -4224) ((marker) . -4227) ((marker) . -4228) ((marker) . -4196) ((marker) . -4197) ((marker) . -4186) ((marker) . -4187) ((marker) . -4190) ((marker) . -4191) ((marker) . -4105) ((marker) . -4106) ((marker) . -4109) ((marker) . -4110) ((marker) . -4113) ((marker) . -4114) ((marker) . -4075) ((marker) . -4076) ((marker) . -4079) ((marker) . -4080) ((marker) . -4066) ((marker) . -4067) ((marker) . -4374) ((marker) . -4375) ((marker) . -4378) ((marker) . -4379) ((marker) . -4364) ((marker) . -4365) ((marker) . -4344) ((marker) . -4345) ((marker) . -4348) ((marker) . -4349) ((marker) . -4312) ((marker) . -4313) ((marker) . -4316) ((marker) . -4317) ((marker) . -4284) ((marker) . -4285) ((marker) . -4680) ((marker) . -4681) ((marker) . -4684) ((marker) . -4685) ((marker) . -4637) ((marker) . -4638) ((marker) . -4641) ((marker) . -4642) ((marker) . -4610) ((marker) . -4611) ((marker) . -4600) ((marker) . -4601) ((marker) . -4604) ((marker) . -4605) ((marker) . -4519) ((marker) . -4520) ((marker) . -4523) ((marker) . -4524) ((marker) . -4527) ((marker) . -4528) ((marker) . -4489) ((marker) . -4490) ((marker) . -4493) ((marker) . -4494) ((marker) . -4480) ((marker) . -4481) ((marker) . -4442) ((marker) . -4443) ((marker) . -4431) ((marker) . -4432) ((marker) . -4700) ((marker) . -4701) ((marker) . -4762) ((marker) . -4763) ((marker) . -4766) ((marker) . -4767) ((marker) . -4728) ((marker) . -4729) ((marker) . -4732) ((marker) . -4733) ((marker) . -4792) ((marker) . -4793) ((marker) . -4796) ((marker) . -4797) ((marker) . -4782) ((marker) . -4783) ((marker) . -4872) ((marker) . -4873) ((marker) . -4861) ((marker) . -4862) ((marker) . -5052) ((marker) . -5053) ((marker) . -5056) ((marker) . -5057) ((marker) . -5035) ((marker) . -5036) ((marker) . -5039) ((marker) . -5040) ((marker) . -5008) ((marker) . -5009) ((marker) . -4938) ((marker) . -4939) ((marker) . -4942) ((marker) . -4943) ((marker) . -4929) ((marker) . -4930) ((marker) . -5302) ((marker) . -5303) ((marker) . -5279) ((marker) . -5280) ((marker) . -5283) ((marker) . -5284) ((marker) . -5222) ((marker) . -5223) ((marker) . -5226) ((marker) . -5227) ((marker) . -5167) ((marker) . -5168) ((marker) . -5171) ((marker) . -5172) ((marker) . -5143) ((marker) . -5144) ((marker) . -5072) ((marker) . -5073) ((marker) . -5420) ((marker) . -5421) ((marker) . -5424) ((marker) . -5425) ((marker) . -5401) ((marker) . -5402) ((marker) . -5390) ((marker) . -5391) ((marker) . -5312) ((marker) . -5313) ((marker) . -5316) ((marker) . -5317) ((marker) . -5634) ((marker) . -5635) ((marker) . -5638) ((marker) . -5639) ((marker) . -5642) ((marker) . -5643) ((marker) . -5605) ((marker) . -5606) ((marker) . -5609) ((marker) . -5610) ((marker) . -5613) ((marker) . -5614) ((marker) . -5559) ((marker) . -5560) ((marker) . -5563) ((marker) . -5564) ((marker) . -5515) ((marker) . -5516) ((marker) . -5519) ((marker) . -5520) ((marker) . -5499) ((marker) . -5500) ((marker) . -5466) ((marker) . -5467) ((marker) . -5470) ((marker) . -5471) ((marker) . -5456) ((marker) . -5457) ((marker) . -5872) ((marker) . -5873) ((marker) . -5876) ((marker) . -5877) ((marker) . -5856) ((marker) . -5857) ((marker) . -5803) ((marker) . -5804) ((marker) . -5748) ((marker) . -5749) ((marker) . -5752) ((marker) . -5753) ((marker) . -5756) ((marker) . -5757) ((marker) . -5677) ((marker) . -5678) ((marker) . -5681) ((marker) . -5682) ((marker) . -5685) ((marker) . -5686) ((marker) . -5663) ((marker) . -5664) ((marker) . -5667) ((marker) . -5668) ((marker) . -6210) ((marker) . -6211) ((marker) . -6140) ((marker) . -6141) ((marker) . -6129) ((marker) . -6130) ((marker) . -6083) ((marker) . -6084) ((marker) . -6072) ((marker) . -6073) ((marker) . -6020) ((marker) . -6021) ((marker) . -6024) ((marker) . -6025) ((marker) . -6010) ((marker) . -6011) ((marker) . -5972) ((marker) . -5973) ((marker) . -5976) ((marker) . -5977) ((marker) . -5962) ((marker) . -5963) ((marker) . -5942) ((marker) . -5943) ((marker) . -5911) ((marker) . -5912) ((marker . 1) . -7109) ((marker . 1) . -7103) ((marker . 1) . -7047) ((marker . 1) . -7047) ((marker . 1) . -7103) ((marker . 1) . -7098) ((marker . 1) . -7109) ((marker . 1) . -7141) ((marker . 1) . -7165) ((marker) . -7354) ((marker) . -7355) ((marker) . -7291) ((marker) . -7292) ((marker) . -7295) ((marker) . -7296) ((marker) . -7291) ((marker) . -7292) ((marker) . -7295) ((marker) . -7296) ((marker) . -7268) ((marker) . -7269) ((marker) . -7247) ((marker) . -7248) ((marker) . -7230) ((marker) . -7231) ((marker) . -7201) ((marker) . -7202) ((marker) . -7190) ((marker) . -7191) ((marker) . -7142) ((marker) . -7143) ((marker) . -7146) ((marker) . -7147) ((marker) . -7110) ((marker) . -7111) ((marker) . -7099) ((marker) . -7100) ((marker) . -7026) ((marker) . -7027) ((marker) . -6993) ((marker) . -6994) ((marker) . -6919) ((marker) . -6920) ((marker) . -6894) ((marker) . -6895) ((marker) . -6847) ((marker) . -6848) ((marker) . -6851) ((marker) . -6852) ((marker) . -6855) ((marker) . -6856) ((marker) . -6811) ((marker) . -6812) ((marker) . -6815) ((marker) . -6816) ((marker) . -6772) ((marker) . -6773) ((marker) . -6776) ((marker) . -6777) ((marker) . -6780) ((marker) . -6781) ((marker) . -6747) ((marker) . -6748) ((marker) . -6751) ((marker) . -6752) ((marker) . -6726) ((marker) . -6727) ((marker) . -6677) ((marker) . -6678) ((marker) . -6616) ((marker) . -6617) ((marker) . -6610) ((marker) . -6611) ((marker) . -6537) ((marker) . -6538) ((marker) . -6541) ((marker) . -6542) ((marker) . -6508) ((marker) . -6509) ((marker) . -6451) ((marker) . -6452) ((marker) . -6445) ((marker) . -6446) ((marker) . -6372) ((marker) . -6373) ((marker) . -6376) ((marker) . -6377) ((marker) . -6344) ((marker) . -6345) ((marker) . -6294) ((marker) . -6295) ((marker . 1) . -6724) ((marker . 1) . -6724) ((marker . 1) . -6724) ((marker . 1) . -6724) ((marker . 1) . -6724) ((marker . 1) . -6707) ((marker . 1) . -6707) ((marker . 1) . -6724) ((marker . 1) . -6724) ((marker . 1) . -6724) ((marker . 1) . -6746) ((marker . 1) . -6771) ((marker . 1) . -6810) ((marker . 1) . -6846) ((marker . 1) . -6892) ((marker . 1) . -6918) ((marker . 1) . -6992) ((marker . 1) . -7025) ((marker . 1) . -7044) ((marker . 1) . -6707) ((marker . 1) . -6724) ((marker) . -6707) ((marker . 1) . -6724) ((marker . 1) . -6707) ((marker) . -6724) (7374 . 14746) 6725) (emacs-pending-undo-list ("s" . -7041) ((marker . 7256) . -1) 7042 nil ("s" . -7002) ((marker . 7256) . -1) 7003 (t 25240 1189 283571 185000) nil ("from icmplib import ping, async_ping
from rich.pretty import pprint
import sys
from bs4 import BeautifulSoup as BS
import json
import subprocess
import os
import re
import secrets
import httpx
import typing as T
import asyncio
import uvloop
import time
import functools
import inspect

asyncio.set_event_loop_policy(uvloop.EventLoopPolicy())


def must_be_root(func):
    \"\"\"
    For commands that require being run as root
    Not used because I don't have a good way of scripting with it
    \"\"\"

    @functools.wraps(func)
    def x():
        uid = os.getuid()
        if uid == 0:
            return func()
        else:
            raise Exception(uid, \"is not root\")

    return x


def check_for_leaks() -> bool:
    \"\"\"Verifies that your connection is reasonably secure\"\"\"
    url = \"https://am.i.mullvad.net/json\"
    with httpx.Client() as client:
        res = client.get(url)
        data = res.json()
        if data[\"blacklisted\"][\"blacklisted\"]:
            return False
        if not data[\"mullvad_exit_ip\"]:
            return False
        return True


def remote_data():
    \"\"\"\"\"\"
    url = \"https://api.mullvad.net/www/relays/all/\"
    with httpx.Client() as client:
        res = client.get(url)
        return res.json()


async def ping_all_hosts(data: list):
    \"\"\"\"\"\"

    async def a(
        ip: str, hostname: str, city_code: str, country_code: str, vpn_proto: str
    ):
        if \":\" in ip:
            family = 6
        else:
            family = 4
        res = await async_ping(
            ip,
            count=18,
            interval=0.8,
            timeout=4,
            id=None,
            source=None,
            family=family,
            privileged=False,
        )
        result = {
            \"hostname\": hostname,
            \"city_code\": city_code,
            \"country_code\": country_code,
            \"vpn_proto\": vpn_proto,
            \"ipv4\": ip,
            \"is_alive\": res.is_alive,
            \"min_rtt\": res.min_rtt,
            \"avg_rtt\": res.avg_rtt,
            \"max_rtt\": res.max_rtt,
            \"packet_loss\": res.packet_loss,
            \"jitter\": res.jitter,
        }
        return result

    ipv4s = list(
        map(
            lambda x: a(
                x[\"ipv4_addr_in\"],
                x[\"hostname\"],
                x[\"city_code\"],
                x[\"country_code\"],
                x[\"type\"],
            ),
            data,
        )
    )
    # My main internet connection does not have ipv6 working, YAY
    # ipv6s = list(filter(None, list(map(lambda x: x[\"ipv6_addr_in\"], data))))
    # ipv6ss = list(map(lambda x: a(x), ipv6s))
    ping4s = await asyncio.gather(*ipv4s)
    # ping6s = await asyncio.gather(*ipv6ss)
    alive = list(filter(lambda x: x[\"is_alive\"], ping4s))
    pings = sorted(alive, key=lambda x: x[\"avg_rtt\"])
    return pings


def get_():
    \"\"\"\"\"\"
    l = remote_data()
    p = asyncio.run(ping_all_hosts(l))
    return p


def filter_vpns(
    protocol: str = \"wireguard\",
    avg_rtt: int = 180,
    max_rtt: int = 210,
    jitter: int = 5,
    packet_loss: float = 0.0,
):
    \"\"\"\"\"\"
    options = get_()
    vpn_proto = list(filter(lambda x: (x[\"vpn_proto\"] == protocol), options))
    packet_loss = list(filter(lambda x: (x[\"packet_loss\"] <= packet_loss), vpn_proto))
    avg_less_then = list(filter(lambda x: (x[\"avg_rtt\"] <= avg_rtt), packet_loss))
    max_less_then = list(filter(lambda x: (x[\"max_rtt\"] <= max_rtt), avg_less_then))
    jitter_less_then = list(filter(lambda x: (x[\"jitter\"] <= jitter), max_less_then))
    return jitter_less_then


def get_current_config() -> str:
    \"\"\"\"\"\"
    cmd = [\"wg show all endpoints\"]
    res = subprocess.run(cmd, shell=True, stdout=subprocess.PIPE)
    conf = res.stdout.decode(\"utf-8\").split(\"\\t\")[0]
    print(conf)
    return conf


def is_up() -> bool:
    \"\"\"Checks if wg has any active connections\"\"\"
    config = get_current_config()
    if config == \"\":
        return False
    else:
        return True


def wg_up(config: str) -> bool:
    \"\"\"\"\"\"
    cmd = [\"wg-quick up \" + config]
    try:
        res = subprocess.run(
            cmd, shell=True, stdout=subprocess.DEVNULL, stderr=subprocess.STDOUT
        )
    except Exception as e:
        raise Exception(\"up cmd failed\")
        sys.exit(1)
    if res.returncode == 0:
        print(config, \" is up\")
        return True
    else:
        return False


def wg_down(config: str) -> bool:
    \"\"\"\"\"\"
    cmd = [\"wg-quick down \" + config]
    try:
        res = subprocess.run(
            cmd, shell=True, stdout=subprocess.DEVNULL, stderr=subprocess.STDOUT
        )
    except Exception as e:
        raise Exception(\"Down cmd failed\")
        sys.exit(1)
    if res.returncode == 0:
        print(config, \" is down\")
        return True
    else:
        return False


def get_all_configs() -> T.Union[list, bool]:
    \"\"\"\"\"\"
    cmd = [\"find /etc/wireguard -type f -name '*.conf'\"]
    try:
        res = subprocess.run(cmd, shell=True, stdout=subprocess.PIPE)
    except Exception as e:
        print(e)
        sys.exit(1)
    stdou = list(filter(None, res.stdout.decode(\"utf-8\").split(\"\\n\")))
    if not stdou == \"\":
        basenames = list(map(os.path.basename, stdou))
        configs = list(map(lambda x: x[:-5], basenames))
        return configs
    else:
        return False


def get_random_config(fully_rand: bool = True) -> str:
    \"\"\"\"\"\"
    if fully_rand:
        configs = get_all_configs()
    else:
        configs = filter_vpns()

    if configs:
        rand_conf = secrets.choice(configs)
        if rand_conf != get_current_config():
            print(rand_conf)
            return rand_conf
        else:
            # Should only recur once, so optimization is not a concern
            return get_random_config()


def rotate():
    \"\"\"Switches to a new, random wireguard config\"\"\"
    if is_up():
        wg_down(get_current_config())

    conf = get_random_config()
    u = wg_up(conf)
    if u:
        print(\"Rotated successfully\")
    else:
        print(\"Failed rotating\")


def _get_help():
    \"\"\"\"\"\"
    print(\"HELPP MEEEE\")


def _local_cmds():
    \"\"\"\"\"\"
    # List of all functions, including imported ones, in local module
    all_functions = list(filter(lambda x: callable(x[1]), list(globals().items())))
    # List of just the functions from this module
    local_functions = list(
        filter(lambda x: (x[1].__module__ == \"__main__\"), all_functions)
    )
    # List of all non-utility functions from this module
    facing_functions = list(
        filter(lambda x: (not re.match(r\"^_.*\", x[0])), local_functions)
    )
    # cli_cmds = list(map(lambda x: x[0], facing_functions))
    return facing_functions


def _help_cmds():

    def d(x: tuple):
        if x[2] is None:
            return (x[0], x[1], \"n/a\")
        elif isinstance(x[2], str):
            return (x[0], x[1], x[2].strip())

    cmds = _local_cmds()
    helps = list(map(lambda x: (x[0], x[1], inspect.getdoc(x[1])), cmds))
    helpss = list(map(d, helps))
    pprint(helpss)


def _exec_on_match(subcmd: str, func_tuple: tuple):
    \"\"\"\"\"\"
    if subcmd == func_tuple[0]:
        func_tuple[1]()


def main(argv: list):
    \"\"\"\"\"\"
    cli_cmds = _local_cmds()
    _help_cmds()
    subcmd = argv[0]
    for c in cli_cmds:
        _exec_on_match(subcmd, c)


if __name__ == \"__main__\":
    main(sys.argv)
" . 1) ((marker* . 1) . 7373) ((marker* . 1) . 7373) ((marker* . 1) . 7373) ((marker* . 1) . 7373) ((marker* . 1) . 7373) ((marker . 7130) . -6724) ((marker* . 1) . 7373) ((marker* . 1) . 7373) ((marker . 6653) . -6294) ((marker . 7256) . -6724) ((marker* . 1) . 7373) ((marker* . 1) . 7373) ((marker* . 1) . 7373) ((marker* . 1) . 7373) ((marker* . 1) . 7373) ((marker* . 1) . 7373) ((marker* . 1) . 7373) ((marker* . 1) . 7373) ((marker* . 1) . 7373) ((marker* . 1) . 7373) ((marker* . 1) . 7373) ((marker* . 1) . 7373) ((marker* . 1) . 7373) ((marker* . 1) . 7373) ((marker* . 1) . 7373) ((marker* . 1) . 7373) ((marker* . 1) . 7373) ((marker* . 1) . 7373) ((marker* . 1) . 7373) ((marker* . 1) . 7373) ((marker* . 1) . 7373) ((marker* . 1) . 7373) ((marker* . 1) . 7373) ((marker* . 1) . 7373) ((marker* . 1) . 7373) ((marker* . 1) . 7373) ((marker* . 1) . 7373) ((marker* . 1) . 7373) ((marker* . 1) . 7373) ((marker* . 1) . 7373) ((marker* . 1) . 7373) ((marker* . 1) . 7373) ((marker* . 1) . 7373) ((marker* . 1) . 7373) ((marker* . 1) . 7373) ((marker* . 1) . 7373) ((marker* . 1) . 7373) ((marker* . 1) . 7373) ((marker* . 1) . 7373) ((marker* . 1) . 7373) ((marker* . 1) . 7373) ((marker) . -3545) ((marker) . -3546) ((marker) . -3459) ((marker) . -3460) ((marker) . -3374) ((marker) . -3375) ((marker) . -3291) ((marker) . -3292) ((marker) . -3204) ((marker) . -3205) ((marker) . -3126) ((marker) . -3127) ((marker) . -3105) ((marker) . -3106) ((marker) . -3094) ((marker) . -3095) ((marker) . -3061) ((marker) . -3062) ((marker) . -3040) ((marker) . -3041) ((marker) . -3016) ((marker) . -3017) ((marker) . -2992) ((marker) . -2993) ((marker) . -2959) ((marker) . -2960) ((marker) . -2927) ((marker) . -2928) ((marker) . -2888) ((marker) . -2889) ((marker) . -2866) ((marker) . -2867) ((marker) . -2855) ((marker) . -2856) ((marker) . -2824) ((marker) . -2825) ((marker) . -2770) ((marker) . -2771) ((marker) . -2712) ((marker) . -2713) ((marker) . -2667) ((marker) . -2668) ((marker) . -2625) ((marker) . -2626) ((marker) . -424) ((marker) . -425) ((marker) . -376) ((marker) . -377) ((marker) . -368) ((marker) . -369) ((marker) . -586) ((marker) . -587) ((marker) . -590) ((marker) . -591) ((marker) . -594) ((marker) . -595) ((marker) . -565) ((marker) . -566) ((marker) . -569) ((marker) . -570) ((marker) . -539) ((marker) . -540) ((marker) . -543) ((marker) . -544) ((marker) . -526) ((marker) . -527) ((marker) . -499) ((marker) . -500) ((marker) . -490) ((marker) . -491) ((marker) . -721) ((marker) . -722) ((marker) . -675) ((marker) . -676) ((marker) . -626) ((marker) . -627) ((marker) . -630) ((marker) . -631) ((marker) . -634) ((marker) . -635) ((marker) . -612) ((marker) . -613) ((marker) . -616) ((marker) . -617) ((marker) . -1052) ((marker) . -1053) ((marker) . -1056) ((marker) . -1057) ((marker) . -1027) ((marker) . -1028) ((marker) . -1031) ((marker) . -1032) ((marker) . -1035) ((marker) . -1036) ((marker) . -987) ((marker) . -988) ((marker) . -991) ((marker) . -992) ((marker) . -962) ((marker) . -963) ((marker) . -966) ((marker) . -967) ((marker) . -970) ((marker) . -971) ((marker) . -915) ((marker) . -916) ((marker) . -919) ((marker) . -920) ((marker) . -889) ((marker) . -890) ((marker) . -893) ((marker) . -894) ((marker) . -859) ((marker) . -860) ((marker) . -863) ((marker) . -864) ((marker) . -824) ((marker) . -825) ((marker) . -782) ((marker) . -783) ((marker) . -1487) ((marker) . -1488) ((marker) . -1491) ((marker) . -1492) ((marker) . -1464) ((marker) . -1465) ((marker) . -1468) ((marker) . -1469) ((marker) . -1472) ((marker) . -1473) ((marker) . -1450) ((marker) . -1451) ((marker) . -1454) ((marker) . -1455) ((marker) . -1427) ((marker) . -1428) ((marker) . -1431) ((marker) . -1432) ((marker) . -1435) ((marker) . -1436) ((marker) . -1405) ((marker) . -1406) ((marker) . -1409) ((marker) . -1410) ((marker) . -1398) ((marker) . -1399) ((marker) . -1316) ((marker) . -1317) ((marker) . -1320) ((marker) . -1321) ((marker) . -1299) ((marker) . -1300) ((marker) . -1287) ((marker) . -1288) ((marker) . -1221) ((marker) . -1222) ((marker) . -1225) ((marker) . -1226) ((marker) . -1191) ((marker) . -1192) ((marker) . -1195) ((marker) . -1196) ((marker) . -1156) ((marker) . -1157) ((marker) . -1104) ((marker) . -1105) ((marker) . -1093) ((marker) . -1094) ((marker) . -2625) ((marker) . -2626) ((marker) . -2577) ((marker) . -2578) ((marker) . -2498) ((marker) . -2499) ((marker) . -2432) ((marker) . -2433) ((marker) . -2426) ((marker) . -2427) ((marker) . -2416) ((marker) . -2417) ((marker) . -2420) ((marker) . -2421) ((marker) . -2398) ((marker) . -2399) ((marker) . -2402) ((marker) . -2403) ((marker) . -2406) ((marker) . -2407) ((marker) . -2383) ((marker) . -2384) ((marker) . -2387) ((marker) . -2388) ((marker) . -2391) ((marker) . -2392) ((marker) . -2356) ((marker) . -2357) ((marker) . -2360) ((marker) . -2361) ((marker) . -2364) ((marker) . -2365) ((marker) . -2368) ((marker) . -2369) ((marker) . -2321) ((marker) . -2322) ((marker) . -2325) ((marker) . -2326) ((marker) . -2329) ((marker) . -2330) ((marker) . -2333) ((marker) . -2334) ((marker) . -2289) ((marker) . -2290) ((marker) . -2293) ((marker) . -2294) ((marker) . -2297) ((marker) . -2298) ((marker) . -2301) ((marker) . -2302) ((marker) . -2258) ((marker) . -2259) ((marker) . -2262) ((marker) . -2263) ((marker) . -2266) ((marker) . -2267) ((marker) . -2270) ((marker) . -2271) ((marker) . -2223) ((marker) . -2224) ((marker) . -2227) ((marker) . -2228) ((marker) . -2231) ((marker) . -2232) ((marker) . -2235) ((marker) . -2236) ((marker) . -2198) ((marker) . -2199) ((marker) . -2202) ((marker) . -2203) ((marker) . -2206) ((marker) . -2207) ((marker) . -2185) ((marker) . -2186) ((marker) . -2189) ((marker) . -2190) ((marker) . -2167) ((marker) . -2168) ((marker) . -2144) ((marker) . -2145) ((marker) . -2148) ((marker) . -2149) ((marker) . -2134) ((marker) . -2135) ((marker) . -2138) ((marker) . -2139) ((marker) . -2100) ((marker) . -2101) ((marker) . -2104) ((marker) . -2105) ((marker) . -2108) ((marker) . -2109) ((marker) . -2056) ((marker) . -2057) ((marker) . -2060) ((marker) . -2061) ((marker) . -2064) ((marker) . -2065) ((marker) . -2020) ((marker) . -2021) ((marker) . -2024) ((marker) . -2025) ((marker) . -2028) ((marker) . -2029) ((marker) . -1984) ((marker) . -1985) ((marker) . -1988) ((marker) . -1989) ((marker) . -1992) ((marker) . -1993) ((marker) . -1948) ((marker) . -1949) ((marker) . -1952) ((marker) . -1953) ((marker) . -1956) ((marker) . -1957) ((marker) . -1910) ((marker) . -1911) ((marker) . -1914) ((marker) . -1915) ((marker) . -1918) ((marker) . -1919) ((marker) . -1886) ((marker) . -1887) ((marker) . -1890) ((marker) . -1891) ((marker) . -1894) ((marker) . -1895) ((marker) . -1850) ((marker) . -1851) ((marker) . -1854) ((marker) . -1855) ((marker) . -1858) ((marker) . -1859) ((marker) . -1808) ((marker) . -1809) ((marker) . -1812) ((marker) . -1813) ((marker) . -1816) ((marker) . -1817) ((marker) . -1772) ((marker) . -1773) ((marker) . -1776) ((marker) . -1777) ((marker) . -1780) ((marker) . -1781) ((marker) . -1738) ((marker) . -1739) ((marker) . -1742) ((marker) . -1743) ((marker) . -1746) ((marker) . -1747) ((marker) . -1719) ((marker) . -1720) ((marker) . -1723) ((marker) . -1724) ((marker) . -1709) ((marker) . -1710) ((marker) . -1713) ((marker) . -1714) ((marker) . -1679) ((marker) . -1680) ((marker) . -1683) ((marker) . -1684) ((marker) . -1687) ((marker) . -1688) ((marker) . -1652) ((marker) . -1653) ((marker) . -1656) ((marker) . -1657) ((marker) . -1660) ((marker) . -1661) ((marker) . -1627) ((marker) . -1628) ((marker) . -1631) ((marker) . -1632) ((marker) . -1635) ((marker) . -1636) ((marker) . -1606) ((marker) . -1607) ((marker) . -1610) ((marker) . -1611) ((marker) . -1614) ((marker) . -1615) ((marker) . -1583) ((marker) . -1584) ((marker) . -1587) ((marker) . -1588) ((marker) . -1591) ((marker) . -1592) ((marker) . -1557) ((marker) . -1558) ((marker) . -1561) ((marker) . -1562) ((marker) . -1565) ((marker) . -1566) ((marker) . -1535) ((marker) . -1536) ((marker) . -1539) ((marker) . -1540) ((marker) . -1543) ((marker) . -1544) ((marker) . -1519) ((marker) . -1520) ((marker) . -1523) ((marker) . -1524) ((marker) . -1527) ((marker) . -1528) ((marker . 1) . -3607) ((marker . 1) . -3575) ((marker) . -3619) ((marker) . -3620) ((marker) . -3608) ((marker) . -3609) ((marker) . -3774) ((marker) . -3775) ((marker) . -3721) ((marker) . -3722) ((marker) . -3655) ((marker) . -3656) ((marker) . -3790) ((marker) . -3791) ((marker) . -3955) ((marker) . -3956) ((marker) . -3934) ((marker) . -3935) ((marker) . -3938) ((marker) . -3939) ((marker) . -3913) ((marker) . -3914) ((marker) . -3879) ((marker) . -3880) ((marker) . -3829) ((marker) . -3830) ((marker) . -4030) ((marker) . -4031) ((marker) . -4019) ((marker) . -4020) ((marker) . -3965) ((marker) . -3966) ((marker) . -3969) ((marker) . -3970) ((marker) . -4264) ((marker) . -4265) ((marker) . -4268) ((marker) . -4269) ((marker) . -4223) ((marker) . -4224) ((marker) . -4227) ((marker) . -4228) ((marker) . -4196) ((marker) . -4197) ((marker) . -4186) ((marker) . -4187) ((marker) . -4190) ((marker) . -4191) ((marker) . -4105) ((marker) . -4106) ((marker) . -4109) ((marker) . -4110) ((marker) . -4113) ((marker) . -4114) ((marker) . -4075) ((marker) . -4076) ((marker) . -4079) ((marker) . -4080) ((marker) . -4066) ((marker) . -4067) ((marker) . -4374) ((marker) . -4375) ((marker) . -4378) ((marker) . -4379) ((marker) . -4364) ((marker) . -4365) ((marker) . -4344) ((marker) . -4345) ((marker) . -4348) ((marker) . -4349) ((marker) . -4312) ((marker) . -4313) ((marker) . -4316) ((marker) . -4317) ((marker) . -4284) ((marker) . -4285) ((marker) . -4680) ((marker) . -4681) ((marker) . -4684) ((marker) . -4685) ((marker) . -4637) ((marker) . -4638) ((marker) . -4641) ((marker) . -4642) ((marker) . -4610) ((marker) . -4611) ((marker) . -4600) ((marker) . -4601) ((marker) . -4604) ((marker) . -4605) ((marker) . -4519) ((marker) . -4520) ((marker) . -4523) ((marker) . -4524) ((marker) . -4527) ((marker) . -4528) ((marker) . -4489) ((marker) . -4490) ((marker) . -4493) ((marker) . -4494) ((marker) . -4480) ((marker) . -4481) ((marker) . -4442) ((marker) . -4443) ((marker) . -4431) ((marker) . -4432) ((marker) . -4700) ((marker) . -4701) ((marker) . -4762) ((marker) . -4763) ((marker) . -4766) ((marker) . -4767) ((marker) . -4728) ((marker) . -4729) ((marker) . -4732) ((marker) . -4733) ((marker) . -4792) ((marker) . -4793) ((marker) . -4796) ((marker) . -4797) ((marker) . -4782) ((marker) . -4783) ((marker) . -4872) ((marker) . -4873) ((marker) . -4861) ((marker) . -4862) ((marker) . -5052) ((marker) . -5053) ((marker) . -5056) ((marker) . -5057) ((marker) . -5035) ((marker) . -5036) ((marker) . -5039) ((marker) . -5040) ((marker) . -5008) ((marker) . -5009) ((marker) . -4938) ((marker) . -4939) ((marker) . -4942) ((marker) . -4943) ((marker) . -4929) ((marker) . -4930) ((marker) . -5302) ((marker) . -5303) ((marker) . -5279) ((marker) . -5280) ((marker) . -5283) ((marker) . -5284) ((marker) . -5222) ((marker) . -5223) ((marker) . -5226) ((marker) . -5227) ((marker) . -5167) ((marker) . -5168) ((marker) . -5171) ((marker) . -5172) ((marker) . -5143) ((marker) . -5144) ((marker) . -5072) ((marker) . -5073) ((marker) . -5420) ((marker) . -5421) ((marker) . -5424) ((marker) . -5425) ((marker) . -5401) ((marker) . -5402) ((marker) . -5390) ((marker) . -5391) ((marker) . -5312) ((marker) . -5313) ((marker) . -5316) ((marker) . -5317) ((marker) . -5634) ((marker) . -5635) ((marker) . -5638) ((marker) . -5639) ((marker) . -5642) ((marker) . -5643) ((marker) . -5605) ((marker) . -5606) ((marker) . -5609) ((marker) . -5610) ((marker) . -5613) ((marker) . -5614) ((marker) . -5559) ((marker) . -5560) ((marker) . -5563) ((marker) . -5564) ((marker) . -5515) ((marker) . -5516) ((marker) . -5519) ((marker) . -5520) ((marker) . -5499) ((marker) . -5500) ((marker) . -5466) ((marker) . -5467) ((marker) . -5470) ((marker) . -5471) ((marker) . -5456) ((marker) . -5457) ((marker) . -5872) ((marker) . -5873) ((marker) . -5876) ((marker) . -5877) ((marker) . -5856) ((marker) . -5857) ((marker) . -5803) ((marker) . -5804) ((marker) . -5748) ((marker) . -5749) ((marker) . -5752) ((marker) . -5753) ((marker) . -5756) ((marker) . -5757) ((marker) . -5677) ((marker) . -5678) ((marker) . -5681) ((marker) . -5682) ((marker) . -5685) ((marker) . -5686) ((marker) . -5663) ((marker) . -5664) ((marker) . -5667) ((marker) . -5668) ((marker) . -6210) ((marker) . -6211) ((marker) . -6140) ((marker) . -6141) ((marker) . -6129) ((marker) . -6130) ((marker) . -6083) ((marker) . -6084) ((marker) . -6072) ((marker) . -6073) ((marker) . -6020) ((marker) . -6021) ((marker) . -6024) ((marker) . -6025) ((marker) . -6010) ((marker) . -6011) ((marker) . -5972) ((marker) . -5973) ((marker) . -5976) ((marker) . -5977) ((marker) . -5962) ((marker) . -5963) ((marker) . -5942) ((marker) . -5943) ((marker) . -5911) ((marker) . -5912) ((marker . 1) . -7109) ((marker . 1) . -7103) ((marker . 1) . -7047) ((marker . 1) . -7047) ((marker . 1) . -7103) ((marker . 1) . -7098) ((marker . 1) . -7109) ((marker . 1) . -7141) ((marker . 1) . -7165) ((marker) . -7354) ((marker) . -7355) ((marker) . -7291) ((marker) . -7292) ((marker) . -7295) ((marker) . -7296) ((marker) . -7291) ((marker) . -7292) ((marker) . -7295) ((marker) . -7296) ((marker) . -7268) ((marker) . -7269) ((marker) . -7247) ((marker) . -7248) ((marker) . -7230) ((marker) . -7231) ((marker) . -7201) ((marker) . -7202) ((marker) . -7190) ((marker) . -7191) ((marker) . -7142) ((marker) . -7143) ((marker) . -7146) ((marker) . -7147) ((marker) . -7110) ((marker) . -7111) ((marker) . -7099) ((marker) . -7100) ((marker) . -7026) ((marker) . -7027) ((marker) . -6993) ((marker) . -6994) ((marker) . -6919) ((marker) . -6920) ((marker) . -6894) ((marker) . -6895) ((marker) . -6847) ((marker) . -6848) ((marker) . -6851) ((marker) . -6852) ((marker) . -6855) ((marker) . -6856) ((marker) . -6811) ((marker) . -6812) ((marker) . -6815) ((marker) . -6816) ((marker) . -6772) ((marker) . -6773) ((marker) . -6776) ((marker) . -6777) ((marker) . -6780) ((marker) . -6781) ((marker) . -6747) ((marker) . -6748) ((marker) . -6751) ((marker) . -6752) ((marker) . -6726) ((marker) . -6727) ((marker) . -6677) ((marker) . -6678) ((marker) . -6616) ((marker) . -6617) ((marker) . -6610) ((marker) . -6611) ((marker) . -6537) ((marker) . -6538) ((marker) . -6541) ((marker) . -6542) ((marker) . -6508) ((marker) . -6509) ((marker) . -6451) ((marker) . -6452) ((marker) . -6445) ((marker) . -6446) ((marker) . -6372) ((marker) . -6373) ((marker) . -6376) ((marker) . -6377) ((marker) . -6344) ((marker) . -6345) ((marker) . -6294) ((marker) . -6295) ((marker . 1) . -6724) ((marker . 1) . -6724) ((marker . 1) . -6724) ((marker . 1) . -6724) ((marker . 1) . -6724) ((marker . 1) . -6707) ((marker . 1) . -6707) ((marker . 1) . -6724) ((marker . 1) . -6724) ((marker . 1) . -6724) ((marker . 1) . -6746) ((marker . 1) . -6771) ((marker . 1) . -6810) ((marker . 1) . -6846) ((marker . 1) . -6892) ((marker . 1) . -6918) ((marker . 1) . -6992) ((marker . 1) . -7025) ((marker . 1) . -7044) ((marker . 1) . -6707) ((marker . 1) . -6724) ((marker) . -6707) ((marker . 1) . -6724) ((marker . 1) . -6707) ((marker) . -6724) (7374 . 14746) 6725) (emacs-undo-equiv-table (193 . -1)))